To install or update profiles, copy both "image" and "profile" folder in the root of your RetroTink4K SD Card. You can overwrite any file that has the same name without worry, unless you made changes to my profiles beforehand.



*Notes*
3DO (3DORGB mod):
For 3DORGB profiles, you might have to modify cropping due to differences between your 3DORGB jumper settings (pixel shift) and mine.
Since there is no 240p test suite for the console, I strongly recommend this calibration suite from 3DO HD: https://www.youtube.com/watch?v=dbLaEQfUxQs.
HDRetrovision cable brightness switch should be set to low.
Link in the description.

Atari 2600 (Composite mod):
This was done with the simplest Atari 2600 composite mod (2 resistors and a transistor). I'd love to grab a 2600RGB if it was still available...

GBA Consolizer (HDMI mod):
GBA mode should be scaled at 4X in the GBA-C OSD. GB and GBC mode should be scaled at 5X in the OSD.

Neo Geo MVS (RGB mod):
Check FirebrandX's AES profile folder for list of games that should use 304 and 320 profiles.
HDRetrovision cable brightness switch should be set to low.

Nintendo NES (Hi-Def NES HDMI mod):
For these profiles to work, these are the settings you need to set in the Hi-Def NES menu.
	Resolution can be set to your preferred one, but I suggest either 640 x 480 or 1280 x 720 (Profiles are made for 640x480, 1280x720 and 1920x1080)
	Horizontal stretch --> None. Set it to the leftmost setting.
	Cropping --> No
	Horizontal Position --> 40 (for any resolution)
	If you absolutely must use 1920x1080, go in the Save and Options menu --> 1080p60 Height --> 4X
	Remember to save your settings.

Enjoy!
- Prof_gLX

****************
*Special Thanks*
****************

- Mike Chi for his incredible work on the many scalers he released, and his continuing support
- FirebrandX for his incredible profiles and tutorials which I took inspiration from
- Wobbling Pixels for his awesome profiles and tutorials which I took inspiration from
- Artemio and all contributors to the 240p Test Suite