Thank you for downloading this pack with all the profiles I made for the RetroTINK 4K ! <3

You'll find profiles for Analogue Pocket FPGA Cores, Nintendo 64, Gamecube, Wii, PS1, PS2,
Sharpscale PSTV, Nintendo Switch and generic HDMI profiles.
All tuned on a LG C1 OLED with HDR, Freesync and Deep Color enabled - no BFI.

Phase and gain calibration has been made for original PAL consoles,
Using 240p Test Suite or testmode.elf for PS2.

Huge thanks to Wobbling Pixels, Kuro Houou, FireBrandX, Mr.Moro, Billgonzo and Maverick, 
For their work on their profiles which I took inspiration of to create profiles in this pack !!

- Fox_83

*----- How to install -----*

Just copy the contents of the zip to the root of your RetroTINK 4K SD Card, 
Erase all the existing files if coming from a previous version of this pack.

*--------------------------*